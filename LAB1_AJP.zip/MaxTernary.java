package project1;
import java.util.Scanner;


public class MaxTernary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scanner = new Scanner(System.in);

        // Input two numbers
        System.out.print("Enter first number: ");
        int num1 = scanner.nextInt();

        System.out.print("Enter second number: ");
        int num2 = scanner.nextInt();

        // Find maximum using ternary operator
        int max = (num1 > num2) ? num1 : num2;

        // Output the result
        System.out.println("Maximum number is: " + max);
        
        scanner.close();

	}

}
