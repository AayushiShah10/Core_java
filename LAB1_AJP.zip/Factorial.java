package project1;
import java.util.Scanner;
public class Factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Scanner scanner = new Scanner(System.in);

	        // Take input from user
	        System.out.print("Enter a number to find factorial: ");
	        int num = scanner.nextInt();

	        // Initialize factorial result
	        int factorial = 1;

	        // Calculate factorial using for loop
	        for (int i = 1; i <= num; i++) {
	            factorial *= i;
	        }

	        // Output result
	        System.out.println("Factorial of " + num + " is: " + factorial);

	        scanner.close();

	}

}
